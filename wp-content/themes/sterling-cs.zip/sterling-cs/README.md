# Sterling Commercial Solutions - WordPress Theme

Professional commercial cleaning services WordPress theme converted from Astro. Features modern design, responsive layouts, and industry-specific content sections.

## Features

- ✅ Responsive design (mobile, tablet, desktop)
- ✅ Modern hero section with call-to-action
- ✅ Service cards with image backgrounds
- ✅ Industry carousel with navigation
- ✅ Custom navigation menus
- ✅ Widget-ready footer areas
- ✅ SEO-friendly structure
- ✅ Accessibility features (ARIA labels, keyboard navigation)

## Requirements

- WordPress 6.0 or higher
- PHP 8.0 or higher

### Development Requirements

- Docker and Docker Compose (for local WordPress environment)
- Composer (for installing WordPress stubs and preventing lint errors)

## Installation

### 1. Upload Theme to WordPress

#### Option A: Via WordPress Admin

1. Zip the `wp-theme` folder
2. Go to WordPress Admin → Appearance → Themes → Add New
3. Click "Upload Theme" and select the zip file
4. Click "Install Now" and then "Activate"

#### Option B: Via FTP/File Manager

1. Upload the entire `wp-theme` folder to `/wp-content/themes/`
2. Rename it to `sterling-theme` (or your preferred name)
3. Go to WordPress Admin → Appearance → Themes
4. Activate "Sterling Commercial Solutions"

### 2. Configure Site Identity

1. Go to **Appearance → Customize → Site Identity**
2. Set your **Site Title**: "Sterling Commercial Solutions"
3. Set your **Tagline**: "Your trusted partner for professional industrial cleaning services"
4. Upload a logo (optional - currently using SVG icon)

### 3. Create Navigation Menus

1. Go to **Appearance → Menus**
2. Create a new menu called "Primary Navigation"
3. Add custom links:
   - About Us → `#about`
   - Services → `#services`
   - Industries → `#industries`
4. Assign to "Primary Menu" location
5. Save menu

### 4. Configure Footer Widgets

1. Go to **Appearance → Widgets**
2. Add widgets to three footer areas:
   - **Footer Widget Area 1**: Custom HTML or Navigation Menu (Our Story)
   - **Footer Widget Area 2**: Custom HTML or Navigation Menu (Services)
   - **Footer Widget Area 3**: Custom HTML or Navigation Menu (Contact)

### 5. Set Homepage

1. Go to **Settings → Reading**
2. Select "A static page" for homepage displays
3. Choose "Front Page" as your homepage
4. Save changes

## Theme Structure

```text
wp-theme/
├── style.css                    # Theme header & info
├── functions.php                # Theme setup & functions
├── header.php                   # Site header
├── footer.php                   # Site footer
├── front-page.php               # Homepage template
├── assets/
│   ├── css/
│   │   └── main.css            # Main stylesheet
│   ├── js/
│   │   └── main.js             # Main JavaScript
│   └── images/                  # Theme images
├── template-parts/
│   ├── content-apart-cards.php  # "What Sets Us Apart" cards
│   ├── content-service-cards.php # Service cards
│   └── content-carousel.php     # Industry carousel
└── README.md                    # This file
```

## Customization

### Change Colors

Edit CSS variables in `assets/css/main.css`:

```css
:root {
    --sterling-silver: #b7bcc2;
    --deep-slate: #434a54;
    --mountain-blue: #2e5d89;
    --lake-mist: #e7eef3;
    --warm-copper: #c67133;
}
```

### Replace Background Images

All image URLs are centrally defined in `assets/css/main.css` for easier management. Simply update the CSS variables in the `:root` section:

#### Hero Background

```css
--hero-bg-image: url('your-image-url.jpg');
```

#### Service Card Images

```css
--service-hardfloor-image: url('your-image-url.jpg');
--service-carpet-image: url('your-image-url.jpg');
--service-window-image: url('your-image-url.jpg');
--service-industrial-image: url('your-image-url.jpg');
```

#### Industry Carousel Images

```css
--carousel-healthcare-image: url('your-image-url.jpg');
--carousel-retail-image: url('your-image-url.jpg');
--carousel-manufacturing-image: url('your-image-url.jpg');
--carousel-office-image: url('your-image-url.jpg');
```

#### About Us Section Images

```css
--about-image-1: url('your-image-url.jpg');
--about-image-2: url('your-image-url.jpg');
--about-image-3: url('your-image-url.jpg');
```

#### Final CTA Background

```css
--cta-bg-image: url('your-image-url.jpg');
```

All images are referenced via CSS classes, so no PHP file modifications are needed to change images.

### Modify Content Sections

- **Hero Content**: Edit `front-page.php` lines 12-72
- **What Sets Us Apart**: Edit `template-parts/content-apart-cards.php`
- **Services**: Edit `template-parts/content-service-cards.php`
- **Industries Carousel**: Edit `template-parts/content-carousel.php`
- **About Us**: Edit `template-parts/content-about.php` - Features unstructured grid layout with highlights, stats, and quote block
- **Final CTA**: Edit `template-parts/content-cta.php` - Call-to-action with slogan, description, and booking button over faded background image

## Development

### Setup Local Development Environment

#### Using Docker (Recommended)

The project includes a Docker Compose setup with **automatic browser refresh** for easy local development:

1. **Start WordPress locally**

    Navigate to the project root and run:

    ```bash
    docker-compose up -d
    ```

    This will:
    - Start WordPress (internal)
    - Start MariaDB database
    - Start Browser-sync with auto-reload at `http://localhost:3000`
    - Mount the `sterling-cs/` theme folder into WordPress (live-synced)

2. **Complete WordPress Installation**

    - Visit `http://localhost:3000` in your browser (note: port 3000, not 80)
    - Follow the WordPress installation wizard
    - Create your admin account

3. **Activate the Theme**

    - Go to **Appearance → Themes**
    - Activate "Sterling Commercial Solutions"

4. **Install Composer Dependencies**

    In the project root, run:

    ```bash
    composer install
    ```

    This installs `php-stubs/wordpress-stubs` which provides type hints and function definitions for WordPress, preventing linting errors in your IDE.

5. **Development Workflow with Auto-Reload**

    - **Access site**: `http://localhost:3000` (for automatic browser refresh)
    - **Browser-sync UI**: `http://localhost:3001` (connection info, reload logs)
    - Make changes to theme files in `sterling-cs/`
    - **CSS changes** → Injected instantly without page reload
    - **PHP/JS/HTML changes** → Browser automatically refreshes within ~500ms
    - No manual refresh needed!
    - Lint errors for WordPress functions will be resolved by the stubs
    - PHP opcache is disabled for immediate updates
    - Debug mode is enabled (check `sterling-cs/debug.log` for errors)

6. **Stop the Environment**

    ```bash
    docker-compose down
    ```

    To remove all data (database, etc.):

    ```bash
    docker-compose down -v
    ```

#### Database Credentials

The Docker setup uses these default credentials:

- **Host**: `db`
- **Database**: `wordpress`
- **Username**: `wordpress`
- **Password**: `wordpress`
- **Root Password**: `somewordpress`

#### Deployment

When deploying to production, only upload the `sterling-cs/` folder. The `vendor/` directory in the project root is for development only.

### Add Custom Post Types

To make services and industries dynamic, add to `functions.php`:

```php
// Register Services Custom Post Type
function sterling_register_services_cpt() {
    register_post_type('service', array(
        'labels' => array(
            'name' => 'Services',
            'singular_name' => 'Service'
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-admin-tools',
    ));
}
add_action('init', 'sterling_register_services_cpt');
```

## Social Media Links

Update in `footer.php` lines 50-64:
Replace `#` with your actual social media URLs.

## Support

For issues or questions about the theme:

- Email: <support@sterlingcommercialsolutions.com>
- Documentation: See original Astro project README

## Migration Notes

This theme was converted from an Astro static site. Key differences:

- **Dynamic Menus**: WordPress navigation menus replace hard-coded links
- **Widget Areas**: Footer content can be managed via widgets
- **Template Parts**: Content sections separated for easier customization
- **PHP Functions**: SVG icons rendered via PHP function
- **WordPress Integration**: Uses wp_head(), wp_footer(), body_class() etc.

## Credits

- **Original Design**: Astro static site
- **Icons**: Lucide Icons (inline SVG)
- **Fonts**: Google Fonts (Montserrat, Source Sans 3, Lora)
- **Images**: Unsplash (placeholder images - replace with your own)

## License

GNU General Public License v2 or later
<http://www.gnu.org/licenses/gpl-2.0.html>
