<!-- Carousel images are defined in assets/css/main.css -->
<div class="carousel-container">
	<div class="carousel-track">
		<!-- Slide 1: Healthcare -->
		<div class="carousel-slide active">
			<div class="slide-content">
				<div class="slide-image-wrapper slide-healthcare" role="img" aria-label="Healthcare facility">
					<div class="slide-overlay"></div>
				</div>
				<div class="slide-text">
					<h3 class="heading-text slide-heading">Healthcare Facilities</h3>
					<p class="body-text slide-description">
						Medical-grade disinfection and sanitization for hospitals, clinics, and medical offices. We follow strict protocols to maintain sterile environments and prevent cross-contamination.
					</p>
					<ul class="industry-features body-text">
						<li>OSHA-compliant cleaning procedures</li>
						<li>Hospital-grade disinfectants</li>
						<li>Specialized biohazard handling</li>
					</ul>
				</div>
			</div>
		</div>

		<!-- Slide 2: Retail -->
		<div class="carousel-slide">
			<div class="slide-content">
				<div class="slide-image-wrapper slide-retail" role="img" aria-label="Retail store">
					<div class="slide-overlay"></div>
				</div>
				<div class="slide-text">
					<h3 class="heading-text slide-heading">Retail Spaces</h3>
					<p class="body-text slide-description">
						Keep your storefront pristine and inviting with our retail cleaning services. We work around your business hours to minimize disruption while maximizing cleanliness.
					</p>
					<ul class="industry-features body-text">
						<li>Off-hours cleaning available</li>
						<li>Window and display maintenance</li>
						<li>High-traffic area focus</li>
					</ul>
				</div>
			</div>
		</div>

		<!-- Slide 3: Manufacturing -->
		<div class="carousel-slide">
			<div class="slide-content">
				<div class="slide-image-wrapper slide-manufacturing" role="img" aria-label="Manufacturing facility">
					<div class="slide-overlay"></div>
				</div>
				<div class="slide-text">
					<h3 class="heading-text slide-heading">Manufacturing & Industrial</h3>
					<p class="body-text slide-description">
						Heavy-duty industrial cleaning for warehouses, factories, and production facilities. We handle grease, oil, chemical residues, and large-scale operations.
					</p>
					<ul class="industry-features body-text">
						<li>Industrial equipment cleaning</li>
						<li>Pressure washing services</li>
						<li>Safety compliance expertise</li>
					</ul>
				</div>
			</div>
		</div>

		<!-- Slide 4: Office Buildings -->
		<div class="carousel-slide">
			<div class="slide-content">
				<div class="slide-image-wrapper slide-office" role="img" aria-label="Office building">
					<div class="slide-overlay"></div>
				</div>
				<div class="slide-text">
					<h3 class="heading-text slide-heading">Office Buildings</h3>
					<p class="body-text slide-description">
						Professional office cleaning that creates a productive work environment. From executive suites to open-plan workspaces, we maintain the highest standards.
					</p>
					<ul class="industry-features body-text">
						<li>Daily or weekly maintenance</li>
						<li>Desk and workstation sanitization</li>
						<li>Common area deep cleaning</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Navigation Controls -->
<button class="carousel-btn carousel-btn-prev" aria-label="Previous slide">
	<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>
</button>
<button class="carousel-btn carousel-btn-next" aria-label="Next slide">
	<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
</button>

<!-- Indicators -->
<div class="carousel-indicators">
	<button class="indicator active" aria-label="Go to slide 1"></button>
	<button class="indicator" aria-label="Go to slide 2"></button>
	<button class="indicator" aria-label="Go to slide 3"></button>
	<button class="indicator" aria-label="Go to slide 4"></button>
</div>
