<!-- About Us Section - Images defined in assets/css/main.css -->
<div class="about-content">
	<div class="about-text-block">
		<h3 class="heading-text about-heading">Your Trusted Cleaning Partners</h3>
		<p class="body-text about-description">
			We're not just another cleaning company. We're a team of dedicated professionals who understand that a clean
			space is the foundation of a successful business. Every surface we touch, every corner we reach, reflects
			our commitment to excellence.
		</p>
	</div>

	<div class="about-image-primary about-img-1" role="img" aria-label="Professional cleaning team at work"></div>

	<div class="about-highlights">
		<div class="about-highlight-item">
			<div class="about-highlight-icon">
				<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none"
					stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
					<circle cx="9" cy="7" r="4" />
					<path d="M22 21v-2a4 4 0 0 0-3-3.87" />
					<path d="M16 3.13a4 4 0 0 1 0 7.75" />
				</svg>
			</div>
			<div class="about-highlight-content">
				<h4 class="body-text-bold">500+ Happy Clients</h4>
				<p class="body-text">Trusted by businesses across multiple industries</p>
			</div>
		</div>

		<div class="about-highlight-item">
			<div class="about-highlight-icon">
				<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none"
					stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path d="M12 2v20M2 12h20" />
				</svg>
			</div>
			<div class="about-highlight-content">
				<h4 class="body-text-bold">Green Certified</h4>
				<p class="body-text">Eco-friendly products and sustainable practices</p>
			</div>
		</div>

		<div class="about-highlight-item">
			<div class="about-highlight-icon">
				<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none"
					stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<path
						d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526" />
					<circle cx="12" cy="8" r="6" />
				</svg>
			</div>
			<div class="about-highlight-content">
				<h4 class="body-text-bold">Award-Winning</h4>
				<p class="body-text">Recognized for excellence in commercial cleaning</p>
			</div>
		</div>
	</div>

	<div class="about-image-secondary about-img-2" role="img" aria-label="Modern cleaned office space"></div>

	<div class="about-quote-block">
		<blockquote class="about-quote accent-text-italic">
			"Direct business quote."
		</blockquote>
		<p class="body-text-bold about-quote-author">— Quote Provider</p>
	</div>

	<div class="about-stats">
		<div class="about-stat-item">
			<span class="about-stat-number">15+</span>
			<span class="about-stat-label body-text">Years Experience</span>
		</div>
		<div class="about-stat-item">
			<span class="about-stat-number">2M+</span>
			<span class="about-stat-label body-text">Square Feet Cleaned</span>
		</div>
		<div class="about-stat-item">
			<span class="about-stat-number">24/7</span>
			<span class="about-stat-label body-text">Service Available</span>
		</div>
	</div>

	<div class="about-image-tertiary about-img-3" role="img" aria-label="Commercial cleaning equipment and supplies">
	</div>
</div>