<!-- About Us Section - Images defined in assets/css/main.css -->
<div class="about-content">
	<div class="about-text-block">
		<h3 class="heading-text about-heading">Your Trusted Cleaning Partners</h3>
		<p class="body-text about-description">
			We're not just another cleaning company. We're a team of dedicated professionals who understand that a clean
			space is the foundation of a successful business. Every surface we touch, every corner we reach, reflects
			our commitment to excellence.
		</p>
	</div>

	<div class="about-image-primary about-img-1" role="img" aria-label="Professional cleaning team at work"></div>

	<div class="about-highlights">
		<div class="about-highlight-item">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/satisfaction.svg"
			     alt="Client Satisfaction Icon"
			     class="about-highlight-icon" />
			<div class="about-highlight-content">
				<h4 class="body-text-bold">Client-Focused Service</h4>
				<p class="body-text">98% satisfaction rate with proven results across all industries</p>
			</div>
		</div>

		<div class="about-highlight-item">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/checklist.svg"
			     alt="Green Certified Icon"
			     class="about-highlight-icon" />
			<div class="about-highlight-content">
				<h4 class="body-text-bold">Green Certified</h4>
				<p class="body-text">EPA-approved products protecting your team and environment</p>
			</div>
		</div>

		<div class="about-highlight-item">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/technical.svg"
			     alt="Expert Technicians Icon"
			     class="about-highlight-icon" />
			<div class="about-highlight-content">
				<h4 class="body-text-bold">Certified Technicians</h4>
				<p class="body-text">Professionally trained staff with specialized certifications</p>
			</div>
		</div>
	</div>

	<div class="about-image-secondary about-img-2" role="img" aria-label="Modern cleaned office space"></div>

	<div class="about-quote-block">
		<blockquote class="about-quote accent-text-italic">
			"Direct business quote."
		</blockquote>
		<p class="body-text-bold about-quote-author">— Quote Provider</p>
	</div>

	<div class="about-stats">
		<div class="about-stat-item">
			<span class="about-stat-number">15+</span>
			<span class="about-stat-label body-text">Years Experience</span>
		</div>
		<div class="about-stat-item">
			<span class="about-stat-number">2M+</span>
			<span class="about-stat-label body-text">Square Feet Cleaned</span>
		</div>
		<div class="about-stat-item">
			<span class="about-stat-number">24/7</span>
			<span class="about-stat-label body-text">Service Available</span>
		</div>
	</div>

	<div class="about-image-tertiary about-img-3" role="img" aria-label="Commercial cleaning equipment and supplies">
	</div>
</div>