<!-- Final CTA Section - Background image defined in assets/css/main.css -->
<div class="cta-overlay"></div>
<div class="cta-content">
	<h2 class="business-branding-bold cta-slogan">Ready for a Cleaner, Healthier Workspace?</h2>
	<p class="body-text cta-description">
		Experience the Sterling difference with professional cleaning services tailored to your business needs. From daily maintenance to deep industrial cleaning, we deliver excellence every time.
	</p>
	<a href="#contact" class="cta-booking-button">
		<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
			<rect width="18" height="18" x="3" y="4" rx="2" ry="2"/>
			<line x1="16" x2="16" y1="2" y2="6"/>
			<line x1="8" x2="8" y1="2" y2="6"/>
			<line x1="3" x2="21" y1="10" y2="10"/>
		</svg>
		Book Your Free Consultation
	</a>
</div>
